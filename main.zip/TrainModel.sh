# conda activate bayesianfusion
#python Main.py TrainModel --Split 0.8;

:'
for Split in {1..9..2};
	do
	Split=$(bc -l <<<"0.1*${Split}")
	python Main.py TrainModel --Split "$Split";
done
'

for i in {0..30};
	do
	python Main.py TrainModel --Split 0.8 --PolDegreeRange 2:5;
done


for i in {0..30};
	do
	python Main.py TrainModel --Split 0.8 --PolDegreeRange 5:8;
done

for i in {0..30};
	do
	python Main.py TrainModel --Split 0.8 --PolDegreeRange 8:12;
done


