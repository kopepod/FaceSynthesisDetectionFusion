# !conda activate bayesianfusion
"""
As the paper states: some polinomial combinations could make the Fusion Model not to converge, e.g., only high degree polinomials generation. In such a case we generate a new polinomial combination automatically an re-train the model.
"""

#import LIB_BayesianFusion
import argparse
import datetime

def main():
	parser = argparse.ArgumentParser(
	"Fake Synthesis Detection via Late Fusion", 
	description = "This code is meant to evaluate face synthesis detection via late fusion");
	subparsers = parser.add_subparsers();

	subparser = subparsers.add_parser("TrainModel",  description = "This code trains a model from binary labels");
	subparser.add_argument("--Epochs", type = int, default = 25);
	subparser.add_argument("--LR", type = float, default = 1e-05, help = "Fusion Model learning rate");
	subparser.add_argument("--DB", type = str, default = "./DATA/FusedDataset.csv");
	subparser.add_argument("--Split", type = float, default = 0.2, help = "Training testing set size");
	subparser.add_argument("--dbn_samples", type = int, default = 200 , help = "Bayesian model samples to map");
	subparser.add_argument("--minacc", type = float, default = 0.95, help = "Minimum acceptable fusion model accuracy");
	subparser.add_argument("--PolDegreeRange", type = str, default = "1:5", help = "Polinomia degree range");
	subparser.add_argument("--Visualize", type = bool, default = True, help = "Visualize polinoma");
	subparser.set_defaults(func = LIB_BayesianFusion.TrainModel);

	subparser = subparsers.add_parser("AttackModel",  description = "This code trains a model from binary labels");
	subparser.add_argument("--Epochs", type = int, default = 50);
	subparser.add_argument("--LR", type = float, default = 1e-05, help = "Fusion Model learning rate");
	subparser.add_argument("--DB", type = str, default = "./DATA/FusedDataset.csv");
	subparser.add_argument("--Split", type = float, default = 0.8, help = "Training testing set size");
	subparser.add_argument("--dbn_samples", type = int, default = 200 , help = "Bayesian model samples to map");
	subparser.add_argument("--minacc", type = float, default = 0.95, help = "Minimum acceptable fusion model accuracy");
	subparser.add_argument("--PolDegreeRange", type = str, default = "2:5", help = "Polinomia degree range");
	subparser.add_argument("--Visualize", type = bool, default = True, help = "Visualize polinoma");
	subparser.add_argument("--AttackType", type = str, default = "Backdoor", help = "{Pollute, Perturbation , Backdoor, Reverse}");
	subparser.add_argument("--TargetClass", type = int, default = 0, help = "{0: Real, 1:Fake, 2: Both}");
	subparser.set_defaults(func = LIB_BayesianFusion.AttackModel);
	
	Options = parser.parse_args();
	
	print(str(Options) + "\n");

	Options.func(Options);




if __name__ == "__main__":
	print("\n" + "\033[0;32m" + "[start] " + str(datetime.datetime.now()) + "\033[0m" + "\n");
	main();
	print("\n" + "\033[0;32m" + "[end] "+ str(datetime.datetime.now()) + "\033[0m" + "\n");
