import datetime, json, os, argparse, torch, numpy, pyro, sys, pandas, pickle, time, pprint, itertools
from tqdm import tqdm
from matplotlib import pyplot
from pyro.infer import SVI, Trace_ELBO, TraceGraph_ELBO
from sklearn.model_selection import train_test_split
#from Model import model, guide, predict
from pyro.distributions import Normal, Categorical

class BayesianModel(torch.nn.Module):
	def __init__(self, input_size, hidden_size, output_size):
		super(BayesianModel, self).__init__()
		self.fc1 = torch.nn.Linear(input_size, hidden_size);
		self.out = torch.nn.Linear(hidden_size, output_size);
		self.act = torch.sigmoid; 
	def forward(self, x):
		x = self.fc1(x)
		x = self.act(x)
		x = self.out(x)
		return x

net = BayesianModel(12, 24, 2)
device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
net = net.to(device);

def pyro_model(x_data, y_data):
	fc1w_prior = Normal(loc=torch.ones_like(net.fc1.weight), scale=torch.ones_like(net.fc1.weight))
	fc1b_prior = Normal(loc=torch.ones_like(net.fc1.bias), scale=torch.ones_like(net.fc1.bias))
	outw_prior = Normal(loc=torch.ones_like(net.out.weight), scale=torch.ones_like(net.out.weight))
	outb_prior = Normal(loc=torch.ones_like(net.out.bias), scale=torch.ones_like(net.out.bias))
	priors = {'fc1.weight': fc1w_prior, 'fc1.bias': fc1b_prior,  'out.weight': outw_prior, 'out.bias': outb_prior}
	# lift module 
	lifted_module = pyro.random_module("module", net, priors)()
	#lifted_module = pyro.nn.module("module", net, priors)
	#lifted_reg_model = lifted_module()
	ActFunc = torch.nn.LogSoftmax(dim=1);
	lhat = ActFunc(lifted_module(x_data))
	pyro.sample("obs", Categorical(logits=lhat), obs=y_data)
	#event_dim = max(lhat.dim() - 1, y_data.dim())
	#pyro.sample("obs", Categorical(logits=lhat).to_event(event_dim), obs=y_data)
	if model_mode == "test":
		lifted_module.eval()
		net.eval()
	if model_mode == "train":
		lifted_module.train()
		net.train()

def guide(x_data, y_data):
	softplus = torch.nn.Softplus()
	# Input layer weight distribution priors
	fc1w_mu = torch.randn_like(net.fc1.weight)
	fc1w_sigma = torch.randn_like(net.fc1.weight)
	fc1w_mu_param = pyro.param("fc1w_mu", fc1w_mu)
	fc1w_sigma_param = softplus(pyro.param("fc1w_sigma", fc1w_sigma))
	fc1w_prior = Normal(loc=fc1w_mu_param, scale=fc1w_sigma_param)
	# Input layer bias distribution priors
	fc1b_mu = torch.randn_like(net.fc1.bias)
	fc1b_sigma = torch.randn_like(net.fc1.bias)
	fc1b_mu_param = pyro.param("fc1b_mu", fc1b_mu)
	fc1b_sigma_param = softplus(pyro.param("fc1b_sigma", fc1b_sigma))
	fc1b_prior = Normal(loc=fc1b_mu_param, scale=fc1b_sigma_param)
	# Output layer weight distribution priors
	outw_mu = torch.randn_like(net.out.weight)
	outw_sigma = torch.randn_like(net.out.weight)
	outw_mu_param = pyro.param("outw_mu", outw_mu)
	outw_sigma_param = softplus(pyro.param("outw_sigma", outw_sigma))
	outw_prior = Normal(loc=outw_mu_param, scale=outw_sigma_param).independent(1)
	# Output layer bias distribution priors
	outb_mu = torch.randn_like(net.out.bias)
	outb_sigma = torch.randn_like(net.out.bias)
	outb_mu_param = pyro.param("outb_mu", outb_mu)
	outb_sigma_param = softplus(pyro.param("outb_sigma", outb_sigma))
	outb_prior = Normal(loc=outb_mu_param, scale=outb_sigma_param)
	priors = {'fc1.weight': fc1w_prior, 'fc1.bias': fc1b_prior, 'out.weight': outw_prior, 'out.bias': outb_prior}
	lifted_module = pyro.random_module("module", net, priors)()
	if model_mode == "test":
		lifted_module.eval()
		net.eval()
	if model_mode == "train":
		lifted_module.train()
		net.train()
	return lifted_module

def predict(X, device, dbn_samples):
	with torch.set_grad_enabled( model_mode == "train" ):
		sampled_models = [guide(None, None) for _ in range(dbn_samples)];
		Y_hat = [model(X).data for model in sampled_models];
		mean = torch.mean(torch.stack(Y_hat), 0);
		Y_hat = numpy.argmax(mean.cpu().numpy(), axis=1);
		confidence = numpy.max(mean.cpu().numpy(), axis=1);
		Y_hat = torch.tensor(Y_hat, dtype=torch.float32);
		Y_hat = Y_hat.to(device);
			
	return Y_hat, confidence;

def dataset_split(DF, device, Split, m_, s_):
	X = numpy.asarray(DF.iloc[:,:-1]);
	Y = numpy.asarray(DF.iloc[:,-1]);
	if m_ is None:
		m_ = numpy.mean(X, axis = 0);
	if s_ is None:
		s_ = numpy.var(X, axis = 0) + sys.float_info.epsilon;
	X = (X - m_)/ s_; 
	
	X_train , X_test , Y_train , Y_test, idx_train, idx_test = train_test_split(X, Y, numpy.arange(len(X)), test_size = Split, random_state = 0);
	
	X_train = torch.tensor(X_train, dtype=torch.float32);
	X_train = X_train.to(device);

	Y_train = torch.tensor(Y_train, dtype=torch.float32);
	Y_train = Y_train.to(device);

	X_test = torch.tensor(X_test, dtype=torch.float32);
	X_test = X_test.to(device);

	Y_test = torch.tensor(Y_test, dtype=torch.float32);
	Y_test = Y_test.to(device);			
	
	return X_train, X_test, Y_train, Y_test, idx_train, idx_test, m_, s_

def Accuracy(X_train, Y_train, device, dbn_samples):
	Y_hat, confidence = predict(X_train, device, dbn_samples);
	acc = torch.sum(Y_hat == Y_train) / len(Y_train);
	confidence = numpy.mean(confidence);
	return acc.cpu().detach().numpy(), confidence;


def TrainingCore(Options, svi, X_train, Y_train, device):
	EL = numpy.array([], dtype = object); # Epoch Loss
	EC = numpy.array([], dtype = object); # Epoch Confidence
	for epoch in (pbar := tqdm(range(Options.Epochs)) ):
		loss = svi.step(X_train, Y_train)	/  len(X_train)
		acc, conf = Accuracy(X_train, Y_train, device, Options.dbn_samples);
		mssg = "Epoch: {epoch:3d}  Loss: {loss:3.3f}   TrainAcc: {acc:3.3f}  TrainConf: {conf:3.3f}".format(epoch = epoch, loss = loss, acc = acc, conf = conf)
		EL = numpy.append(EL, loss);
		EC = numpy.append(EC, conf);
		pbar.set_description(mssg)

	return EL, EC;

def TrainModel(Options):
	RunTime = - time.time();

	device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

	if torch.cuda.is_available():
		os.system("nvidia-smi");

	optimizer = torch.optim.SGD
	scheduler = pyro.optim.ExponentialLR({'optimizer': optimizer, 'optim_args': {'lr': Options.LR}, 'gamma': 0.1})
	svi = SVI(pyro_model, guide, scheduler, loss=TraceGraph_ELBO())
	dbn_samples = Options.dbn_samples;
	
	DF = pandas.read_csv(Options.DB);
	
	DFpol, Key = RandomPolinomia(DF, Options, last_idx = -1)

	print('\nTraining ... ')

	acc = 0; retry = 0; k = 0;
	
	while acc < Options.minacc:
		X_train, X_test, Y_train, Y_test, _ , _, _, _  = dataset_split(DFpol, device, Options.Split, m_ = None, s_ = None, last_idx = -1);	
		EL, EC = TrainingCore(Options, svi, X_train, Y_train, device);
		acc, conf = Accuracy(X_test, Y_test, device, dbn_samples);
		if acc > Options.minacc:
			break
		k += 1;
		if k == 3:
			print("\nTrying a new polinomia\n");
			k = 0; retry += 1;
			DFpol, Key = RandomPolinomia(DF, Options, last_idx = -1)
		

	print('\nTesting ... ')

	print("Test Accuracy: %0.3f \t Test Confidence: %0.3f" % (acc, conf))
	
	Y_hat, confidence = predict(X_test, device, dbn_samples);
	
	confidence = numpy.asarray(confidence, dtype = object);
	Y_hat = numpy.asarray(Y_hat.cpu().detach().numpy(), dtype = object);
	Y_test = numpy.asarray(Y_test.cpu().detach().numpy(), dtype = object);
	
	RunTime += time.time();
	
	Sesion = {
		"NameSpace" : str(Options),
		"Key" : Key,
		"Retry" : int(retry),
		"RunTime" : float(RunTime),
		"BinAcc" : float(acc),
		"KeyLength" : len(Key),
		"EpochLoss" : list(EL),
		"EpochConfidence" : list(EC),
		"Y_hat" : list(Y_hat),
		"Y_test" : list(Y_test),
		"Confidence" : list(confidence),		
	}
	
	JSONFile = "./JSON/" + datetimestring() + ".json";
	
	pyplot.savefig(JSONFile.replace("json","png"));
	
	print("\nWritting %s ... " %(JSONFile) );
	
	json_obj = json.dumps(Sesion, indent = 3);
	
	with open(JSONFile, "w") as fid:
		fid.write(json_obj)


def datetimestring():
	newFile = str(datetime.datetime.now());
	newFile = newFile.split(".")[0];
	newFile = newFile.replace(" ", "_");
	newFile = newFile.replace(":", "_");
	newFile = newFile.replace("-", "_")
	return newFile
	
def RandomPolinomia(DF, Options):
	PolDegreeRange = Options.PolDegreeRange.split(":");
	a = int(PolDegreeRange[0]);
	b = int(PolDegreeRange[-1]);
	pyplot.figure(figsize = [16,9]);
	#DF = pandas.read_csv("/home/re8is/Dropbox/BayesianFusion/DATA/FusedDataset.csv")
	Key = numpy.array([],dtype = object)
	for k in range(0, len(DF.columns) -1):
		Xk = DF.iloc[:,k];
		n = numpy.random.randint(low = a, high = b);
		p = numpy.random.randint(low = 0, high = 4, size = n);
		Yk = numpy.polyval(0.25 * p, Xk);
		if Options.Visualize:
			pyplot.plot(Xk, Yk , linestyle = "None", marker = ".", alpha = 0.7, markersize = 0.5);
		DF.iloc[:,k] = Yk
		Key = numpy.append(Key, p);
	
	if Options.Visualize:
		pyplot.title("Polinomial Projection Last Layers")
		pyplot.xscale("log")
		pyplot.yscale("log")
		pyplot.xlabel("Last Layer Value Output");
		pyplot.ylabel("Last Layer Value Projection");
		#pyplot.savefig(newFile);
	
	return (DF, list(Key))

'''

Attacks Section

'''


def ReverseAttack(train_conf,X_test, Y_test, device, dbn_samples, DF):
	Y_hat, confidence = predict(X_test, device, dbn_samples);
	X_test = X_test[Y_hat != Y_test]; # adversarial samples
	Y_test = Y_test[Y_hat != Y_test]; # adversarial labels
	DFresults = pandas.DataFrame(columns = ["Models", "SR", "SC"]);
	
	iters = []
	for k in range(1,7):
		for cols in itertools.combinations( list(range(0,11,2)) ,k):
			for _ in range(5):
				iters.append(cols);

	for cols in (pbar := tqdm( iters ) ):
		cols = list(cols);
		Models = ",".join(list(DF.columns[cols].values));
		pbar.set_description("Combination : %s" %(Models.replace("_0","")));
		cols = numpy.asarray([[x+1,x] for x in cols]).flatten();
		X_val = X_test;
		X_val[:,numpy.sort(cols)] = X_val[:,cols];
		Y_hat, confidence = predict(X_val, device, dbn_samples);
		success_rate = torch.sum(Y_hat != Y_test)/len(Y_hat);
		success_rate = success_rate.cpu().detach().numpy()
		success_confidence = numpy.mean(confidence);
		Stats = {"Models": Models, "SR" : success_rate, "SC" :  success_confidence };
		DFresults = pandas.concat([DFresults, pandas.DataFrame([Stats])], ignore_index = True);
	#
	DFresults = DFresults.assign(ref_conf = train_conf);	
	File = "./CSV/Attacks/Reverse_" + datetimestring() + ".csv";
	DFresults.to_csv(File, index = False);
	
def BackDoorAttack(train_conf, X_test, Y_test, device, dbn_samples, DF):
	Y_hat, confidence = predict(X_test, device, dbn_samples);
	X_test = X_test[Y_hat == Y_test]; # adversarial samples
	Y_test = Y_test[Y_hat == Y_test]; # adversarial labels
	DFresults = pandas.DataFrame(columns = ["Models", "SR", "SC"]);
	
	Y_test, indices = torch.sort(Y_test);
	X_test = X_test[indices, :];
	
	iters = []
	for k in range(1,7):
		for cols in itertools.combinations( list(range(0,11,2)) ,k):
			for _ in range(5):		
				iters.append(cols);

	for cols in (pbar := tqdm( iters ) ):
		cols = list(cols);
		Models = ",".join(list(DF.columns[cols].values));
		pbar.set_description("Combination : %s" %(Models.replace("_0","")));
		X_val = X_test;
		#cols = numpy.asarray([[x+1,x] for x in cols]).flatten();
		#X_val[:,numpy.sort(cols)] = X_val[:,cols];
		
		#cols = numpy.asarray([[x,x+1] for x in cols]).flatten();
		cols = [[x,x+1] for x in cols];
		cols = sum(cols, [])
		#X_val[:, cols] = X_val[::-1, cols];
		
		X_val[:, cols] = torch.flip(X_val[:, cols],[0])
		
		Y_hat, confidence = predict(X_val, device, dbn_samples);
		success_rate = torch.sum(Y_hat != Y_test)/len(Y_hat);
		success_rate = success_rate.cpu().detach().numpy()
		success_confidence = numpy.mean(confidence);
		Stats = {"Models": Models, "SR" : success_rate, "SC" :  success_confidence };
		DFresults = pandas.concat([DFresults, pandas.DataFrame([Stats])], ignore_index = True);
	#
	DFresults = DFresults.assign(ref_conf = train_conf);	
	File = "./CSV/Attacks/Backdoor_" + datetimestring() + ".csv";
	DFresults.to_csv(File, index = False);	

def PerturbationAttack(train_conf, X_test, Y_test, device, dbn_samples, DF):
	model_mode = "test"
	DFresults = pandas.DataFrame(columns = ["Models", "mu_", "sigma_", "SR", "SC_accepted", "SC_rejected"]);
	mu_ , sigma_ = numpy.meshgrid(numpy.linspace(-10, 10, 6), numpy.linspace(0, 2, 3) );
	mu_ , sigma_ = mu_.flatten() , sigma_.flatten();
	iters = []
	for k in range(1,7):
		for cols in itertools.combinations( list(range(0,11,2)) ,k):
			iters.append(cols);
	#
	for cols in (pbar := tqdm( iters ) ):
		cols = numpy.asarray(list(cols));
		Models = ",".join(list(DF.columns[cols].values))
		pbar.set_description("Combination : %s" %(Models.replace("_0","")));
		cols = numpy.concatenate([cols,cols+1])
		cols = numpy.sort(cols);
		for mu_i, sigma_i in zip(mu_, sigma_):
			X_val = X_test;
			Xp = torch.rand( len(X_test), len(cols)) - 0.5;
			Xp = Xp.to(device);
			X_val[:,cols] = sigma_i * X_val[:,cols] + mu_i * Xp;
			#
			Y_hat, confidence = predict(X_val, device, dbn_samples);
			success_rate = torch.sum(Y_hat == Y_test) / len(Y_test);
			success_rate = 1-success_rate.cpu().detach().numpy()
			sc_accepted = numpy.mean(confidence[  (Y_hat == Y_test).cpu().detach().numpy() ]);
			sc_rejected = numpy.mean(confidence[  (Y_hat != Y_test).cpu().detach().numpy() ]);
			Stats = {"Models": Models, "mu_": mu_i , "sigma_": sigma_i, "SR" : success_rate, "SC_accepted" :  sc_accepted , "SC_rejected" :  sc_rejected };
			DFresults = pandas.concat([DFresults, pandas.DataFrame([Stats])], ignore_index = True);
	#
	DFresults = DFresults.assign(ref_conf = train_conf);
	File = "./CSV/Attacks/Perturbation_" + datetimestring() + ".csv";
	DFresults.to_csv(File, index = False);



def PolluteAttack(DF, device, svi, Options):
	DFresults = pandas.DataFrame(columns = ["InfectionRate", "SR", "SC",  "Train_acc", "Train_conf"]);

	for InfectionRate in tqdm( numpy.linspace(0.1,0.9,20) , total = 20):
		X_train, X_test, Y_train, Y_test, idx_train, idx_test, m_, s_ = dataset_split(DF, device, Split = 0.8, m_ = None, s_ = None);
		train_acc, train_conf = Accuracy(X_train, Y_train, device, Options.dbn_samples);
		N = len(Y_train);
		idx = numpy.random.choice( N, int(InfectionRate * N) , replace = False);
		Y_train[idx] = 1 - Y_train[idx];
		_, _ = TrainingCore(Options, svi, X_train, Y_train, device);
		success_rate, success_conf = Accuracy(X_test, Y_test, device, Options.dbn_samples);
		success_rate = 1 - success_rate;
		success_conf = numpy.mean(success_conf);
		Stats = {"InfectionRate" : InfectionRate ,  "SR" : success_rate, "SC" :  success_conf, "Train_acc": train_acc, "Train_conf" : train_conf };
		DFresults = pandas.concat([DFresults, pandas.DataFrame([Stats])], ignore_index = True);
	#
	File = "./CSV/Attacks/Pollute_" + datetimestring() + ".csv";
	DFresults.to_csv(File, index = False);	

def AttackModel(Options):
	device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

	if torch.cuda.is_available():
		os.system("nvidia-smi");

	optimizer = torch.optim.SGD
	scheduler = pyro.optim.ExponentialLR({'optimizer': optimizer, 'optim_args': {'lr': Options.LR}, 'gamma': 0.1})
	svi = SVI(pyro_model, guide, scheduler, loss=TraceGraph_ELBO())
	dbn_samples = Options.dbn_samples;
	
	DF = pandas.read_csv(Options.DB);

	DFpol, _ = RandomPolinomia(DF, Options);

	print('\nTraining ... \n')

	k = 0; acc = 0;
	global model_mode
	model_mode = "train";
	
	while acc < Options.minacc:
		X_train, X_test, Y_train, Y_test, idx_train, idx_test, m_, s_ = dataset_split(DFpol, device, Options.Split, m_ = None, s_ = None);
		try:
			_, _ = TrainingCore(Options, svi, X_train, Y_train, device);
			train_acc, train_conf = Accuracy(X_test, Y_test, device, dbn_samples);
		except:
			DFpol, _ = RandomPolinomia(DF, Options);
			continue
		
		if train_acc > Options.minacc:
			print("\nAttack : %s\n" %(Options.AttackType) )
			
			if Options.AttackType == "Pollute":
				PolluteAttack(DFpol, device, svi, Options);

			if Options.AttackType == "Perturbation":
				PerturbationAttack(train_conf, X_test, Y_test, device, dbn_samples, DFpol);

			if Options.AttackType == "Backdoor":
				BackDoorAttack(train_conf, X_test, Y_test, device, dbn_samples, DFpol);

			if Options.AttackType == "Reverse":
				# find advesarials => redo split
				_, X_test, _, Y_test, _, _, _, _ = dataset_split(DFpol, device, Split = 0.98, m_ = m_, s_ = s_);	
				ReverseAttack(train_conf, X_test, Y_test, device, dbn_samples, DFpol);
				
			break
		k += 1;
		if k == 3:
			print("\nTrying a new polinomia\n");
			k = 0; 
			DFpol, _ = RandomPolinomia(DF, Options);
		















































	
